package com.muti.lokerku_muti;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditProfileActivity extends AppCompatActivity {

    private EditText edtNama;
    private EditText edtEmail;
    private EditText edtTelepon;

    private Button btnSimpan;

    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_edit_profile);

        // =========================
        // HUBUNGKAN DENGAN XML
        // =========================

        edtNama = findViewById(R.id.edtNama);
        edtEmail = findViewById(R.id.edtEmail);
        edtTelepon = findViewById(R.id.edtTelepon);

        btnSimpan = findViewById(R.id.btnSimpan);


        // =========================
        // SHARED PREFERENCES
        // =========================

        preferences = getSharedPreferences(
                "data_profil",
                MODE_PRIVATE
        );


        // =========================
        // TAMPILKAN DATA LAMA
        // =========================

        edtNama.setText(
                preferences.getString("nama", "")
        );

        edtEmail.setText(
                preferences.getString("email", "")
        );

        edtTelepon.setText(
                preferences.getString("telepon", "")
        );


        // =========================
        // TOMBOL SIMPAN
        // =========================

        btnSimpan.setOnClickListener(v -> {

            String nama = edtNama.getText().toString().trim();
            String email = edtEmail.getText().toString().trim();
            String telepon = edtTelepon.getText().toString().trim();


            // =========================
            // CEK NAMA
            // =========================

            if (nama.isEmpty()) {

                edtNama.setError("Nama belum diisi");
                edtNama.requestFocus();

                return;
            }


            // =========================
            // CEK EMAIL
            // =========================

            if (email.isEmpty()) {

                edtEmail.setError("Email belum diisi");
                edtEmail.requestFocus();

                return;
            }


            // =========================
            // CEK NOMOR HP
            // =========================

            if (telepon.isEmpty()) {

                edtTelepon.setError("Nomor HP belum diisi");
                edtTelepon.requestFocus();

                return;
            }


            // =========================
            // SIMPAN DATA
            // =========================

            SharedPreferences.Editor editor =
                    preferences.edit();

            editor.putString("nama", nama);
            editor.putString("email", email);
            editor.putString("telepon", telepon);

            editor.apply();


            // =========================
            // PESAN BERHASIL
            // =========================

            Toast.makeText(
                    EditProfileActivity.this,
                    "Profil berhasil disimpan",
                    Toast.LENGTH_SHORT
            ).show();


            // =========================
            // KEMBALI KE PROFILE
            // =========================

            Intent intent = new Intent(
                    EditProfileActivity.this,
                    ProfileActivity.class
            );

            startActivity(intent);

            finish();

        });
    }
}