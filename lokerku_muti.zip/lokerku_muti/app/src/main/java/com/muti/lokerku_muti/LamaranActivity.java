package com.muti.lokerku_muti;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LamaranActivity extends AppCompatActivity {

    private TextView txtJudulLamaran;
    private TextView txtPerusahaanLamaran;
    private TextView txtLokasiLamaran;

    private Button btnKirimLamaran;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_lamaran);


        // =========================
        // HUBUNGKAN DENGAN XML
        // =========================

        txtJudulLamaran =
                findViewById(R.id.txtJudulLamaran);

        txtPerusahaanLamaran =
                findViewById(R.id.txtPerusahaanLamaran);

        txtLokasiLamaran =
                findViewById(R.id.txtLokasiLamaran);

        btnKirimLamaran =
                findViewById(R.id.btnKirimLamaran);


        // =========================
        // AMBIL DATA DARI DETAIL
        // =========================

        String lowonganId =
                getIntent().getStringExtra("lowongan_id");

        String judul =
                getIntent().getStringExtra("judul");

        String perusahaan =
                getIntent().getStringExtra("perusahaan");

        String lokasi =
                getIntent().getStringExtra("lokasi");


        // =========================
        // BUAT ID CADANGAN
        // =========================

        if (lowonganId == null || lowonganId.isEmpty()) {

            lowonganId = "lowongan_" +
                    (judul != null ? judul : "unknown");

        }


        // =========================
        // TAMPILKAN DATA
        // =========================

        if (judul != null && !judul.isEmpty()) {

            txtJudulLamaran.setText(judul);

        }

        if (perusahaan != null && !perusahaan.isEmpty()) {

            txtPerusahaanLamaran.setText(perusahaan);

        }

        if (lokasi != null && !lokasi.isEmpty()) {

            txtLokasiLamaran.setText(lokasi);

        }


        // =========================
        // SIMPAN ID FINAL
        // =========================

        final String finalLowonganId = lowonganId;


        // =========================
        // TOMBOL KIRIM LAMARAN
        // =========================

        btnKirimLamaran.setOnClickListener(v -> {


            // =========================
            // SIMPAN STATUS LAMARAN
            // =========================

            SharedPreferences preferences =
                    getSharedPreferences(
                            "data_lamaran",
                            MODE_PRIVATE
                    );


            SharedPreferences.Editor editor =
                    preferences.edit();


            editor.putBoolean(
                    finalLowonganId,
                    true
            );


            editor.apply();


            // =========================
            // PESAN BERHASIL
            // =========================

            Toast.makeText(
                    LamaranActivity.this,
                    "Lamaran berhasil dikirim",
                    Toast.LENGTH_SHORT
            ).show();


            // =========================
            // KEMBALI
            // =========================

            finish();

        });

    }

}