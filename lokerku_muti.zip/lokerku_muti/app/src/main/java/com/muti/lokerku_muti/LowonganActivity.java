package com.muti.lokerku_muti;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LowonganActivity extends AppCompatActivity {

    private LinearLayout navHome;
    private LinearLayout navLowongan;
    private LinearLayout navTersimpan;
    private LinearLayout navProfil;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_lowongan);


        // =====================================
        // NAVIGATION
        // =====================================

        navHome = findViewById(R.id.navHome);
        navLowongan = findViewById(R.id.navLowongan);
        navTersimpan = findViewById(R.id.navTersimpan);
        navProfil = findViewById(R.id.navProfil);


        // =====================================
        // DETAIL 1
        // =====================================

        TextView btnDetail1 =
                findViewById(R.id.btnDetail1);

        btnDetail1.setOnClickListener(v -> {

            bukaDetail(
                    "Android Developer",
                    "PT Teknologi Indonesia",
                    "Jakarta",
                    "Full Time",
                    "Rp 5 - 8 Juta / bulan",
                    "Bertanggung jawab mengembangkan aplikasi Android menggunakan Java, melakukan pengujian aplikasi, memperbaiki bug dan melakukan pemeliharaan aplikasi.",
                    "LOKER001"
            );

        });


        // =====================================
        // DETAIL 2
        // =====================================

        TextView btnDetail2 =
                findViewById(R.id.btnDetail2);

        btnDetail2.setOnClickListener(v -> {

            bukaDetail(
                    "UI/UX Designer",
                    "Creative Digital Studio",
                    "Bandung",
                    "Full Time",
                    "Rp 4 - 7 Juta / bulan",
                    "Membuat desain antarmuka aplikasi, wireframe, prototype dan meningkatkan pengalaman pengguna.",
                    "LOKER002"
            );

        });


        // =====================================
        // DETAIL 3
        // =====================================

        TextView btnDetail3 =
                findViewById(R.id.btnDetail3);

        btnDetail3.setOnClickListener(v -> {

            bukaDetail(
                    "Digital Marketing",
                    "PT Media Kreatif",
                    "Medan",
                    "Full Time",
                    "Rp 4 - 6 Juta / bulan",
                    "Membuat strategi pemasaran digital, mengelola media sosial dan menganalisis performa kampanye.",
                    "LOKER003"
            );

        });


        // =====================================
        // HOME
        // =====================================

        navHome.setOnClickListener(v -> {

            startActivity(
                    new Intent(
                            LowonganActivity.this,
                            HomeActivity.class
                    )
            );

            finish();

        });


        // =====================================
        // LOWONGAN
        // =====================================

        navLowongan.setOnClickListener(v -> {

            // Sudah berada di halaman Lowongan

        });


        // =====================================
        // TERSIMPAN
        // =====================================

        navTersimpan.setOnClickListener(v -> {

            startActivity(
                    new Intent(
                            LowonganActivity.this,
                            TersimpanActivity.class
                    )
            );

        });


        // =====================================
        // PROFIL
        // =====================================

        navProfil.setOnClickListener(v -> {

            startActivity(
                    new Intent(
                            LowonganActivity.this,
                            ProfileActivity.class
                    )
            );

        });

    }


    private void bukaDetail(
            String judul,
            String perusahaan,
            String lokasi,
            String tipe,
            String gaji,
            String deskripsi,
            String lowonganId) {


        Intent intent = new Intent(
                LowonganActivity.this,
                DetailLowonganActivity.class
        );


        intent.putExtra("judul", judul);
        intent.putExtra("perusahaan", perusahaan);
        intent.putExtra("lokasi", lokasi);
        intent.putExtra("tipe", tipe);
        intent.putExtra("gaji", gaji);
        intent.putExtra("deskripsi", deskripsi);
        intent.putExtra("lowongan_id", lowonganId);


        startActivity(intent);

    }

}