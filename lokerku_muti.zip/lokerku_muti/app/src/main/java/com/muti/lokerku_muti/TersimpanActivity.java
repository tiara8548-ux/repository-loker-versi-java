package com.muti.lokerku_muti;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TersimpanActivity extends AppCompatActivity {

    private LinearLayout containerTersimpan;
    private TextView txtKosong;
    private TextView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_tersimpan);

        containerTersimpan =
                findViewById(R.id.containerTersimpan);

        txtKosong =
                findViewById(R.id.txtKosong);

        btnBack =
                findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        tampilkanLowonganTersimpan();
    }

    @Override
    protected void onResume() {

        super.onResume();

        tampilkanLowonganTersimpan();
    }

    private void tampilkanLowonganTersimpan() {

        containerTersimpan.removeAllViews();

        SharedPreferences preferences =
                getSharedPreferences(
                        "bookmark_loker",
                        MODE_PRIVATE
                );

        boolean adaData = false;

        // ==============================
        // IT
        // ==============================

        if (preferences.getBoolean(
                "IT_001",
                false
        )) {

            tambahLowongan(
                    "Android Developer",
                    "PT Teknologi Indonesia",
                    "Jakarta",
                    "Rp 5 - 8 Juta / bulan",
                    "IT_001"
            );

            adaData = true;
        }

        if (preferences.getBoolean(
                "IT_002",
                false
        )) {

            tambahLowongan(
                    "Web Developer",
                    "PT Digital Nusantara",
                    "Bandung",
                    "Rp 5 - 9 Juta / bulan",
                    "IT_002"
            );

            adaData = true;
        }

        if (preferences.getBoolean(
                "IT_003",
                false
        )) {

            tambahLowongan(
                    "Backend Developer",
                    "Tech Solutions Indonesia",
                    "Surabaya",
                    "Rp 6 - 10 Juta / bulan",
                    "IT_003"
            );

            adaData = true;
        }

        // ==============================
        // DESIGN
        // ==============================

        if (preferences.getBoolean(
                "Design_001",
                false
        )) {

            tambahLowongan(
                    "UI/UX Designer",
                    "Creative Digital Studio",
                    "Bandung",
                    "Rp 4 - 7 Juta / bulan",
                    "Design_001"
            );

            adaData = true;
        }

        if (preferences.getBoolean(
                "Design_002",
                false
        )) {

            tambahLowongan(
                    "Graphic Designer",
                    "Pixel Creative Agency",
                    "Jakarta",
                    "Rp 4 - 6 Juta / bulan",
                    "Design_002"
            );

            adaData = true;
        }

        if (preferences.getBoolean(
                "Design_003",
                false
        )) {

            tambahLowongan(
                    "Illustrator",
                    "Visual Art Studio",
                    "Yogyakarta",
                    "Rp 3 - 6 Juta / bulan",
                    "Design_003"
            );

            adaData = true;
        }

        // ==============================
        // MARKETING
        // ==============================

        if (preferences.getBoolean(
                "Marketing_001",
                false
        )) {

            tambahLowongan(
                    "Digital Marketing",
                    "PT Media Kreatif",
                    "Medan",
                    "Rp 4 - 7 Juta / bulan",
                    "Marketing_001"
            );

            adaData = true;
        }

        if (preferences.getBoolean(
                "Marketing_002",
                false
        )) {

            tambahLowongan(
                    "Social Media Specialist",
                    "Social Media Indonesia",
                    "Jakarta",
                    "Rp 4 - 6 Juta / bulan",
                    "Marketing_002"
            );

            adaData = true;
        }

        if (preferences.getBoolean(
                "Marketing_003",
                false
        )) {

            tambahLowongan(
                    "Content Creator",
                    "Creative Media Group",
                    "Bali",
                    "Rp 3 - 6 Juta / bulan",
                    "Marketing_003"
            );

            adaData = true;
        }

        // ==============================
        // ADMIN
        // ==============================

        if (preferences.getBoolean(
                "Admin_001",
                false
        )) {

            tambahLowongan(
                    "Admin Office",
                    "PT Maju Bersama",
                    "Jakarta",
                    "Rp 3 - 5 Juta / bulan",
                    "Admin_001"
            );

            adaData = true;
        }

        if (preferences.getBoolean(
                "Admin_002",
                false
        )) {

            tambahLowongan(
                    "Staff Administrasi",
                    "PT Sukses Mandiri",
                    "Bekasi",
                    "Rp 3 - 5 Juta / bulan",
                    "Admin_002"
            );

            adaData = true;
        }

        if (preferences.getBoolean(
                "Admin_003",
                false
        )) {

            tambahLowongan(
                    "Data Entry",
                    "Data Solutions",
                    "Tangerang",
                    "Rp 3 - 5 Juta / bulan",
                    "Admin_003"
            );

            adaData = true;
        }

        // ==============================
        // KOSONG
        // ==============================

        if (adaData) {

            txtKosong.setVisibility(
                    View.GONE
            );

        } else {

            txtKosong.setVisibility(
                    View.VISIBLE
            );
        }
    }

    private void tambahLowongan(
            String judul,
            String perusahaan,
            String lokasi,
            String gaji,
            String lowonganId) {

        LinearLayout card =
                new LinearLayout(this);

        card.setOrientation(
                LinearLayout.VERTICAL
        );

        card.setPadding(
                20,
                18,
                20,
                18
        );

        card.setBackgroundResource(
                R.drawable.bg_job_card
        );

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        params.setMargins(
                0,
                0,
                0,
                16
        );

        card.setLayoutParams(params);

        // ==============================
        // JUDUL
        // ==============================

        TextView txtJudul =
                new TextView(this);

        txtJudul.setText(judul);

        txtJudul.setTextSize(18);

        txtJudul.setTextColor(
                getResources().getColor(
                        android.R.color.black
                )
        );

        txtJudul.setTypeface(
                null,
                android.graphics.Typeface.BOLD
        );

        // ==============================
        // PERUSAHAAN
        // ==============================

        TextView txtPerusahaan =
                new TextView(this);

        txtPerusahaan.setText(
                perusahaan
        );

        txtPerusahaan.setTextSize(13);

        txtPerusahaan.setTextColor(
                0xFF64748B
        );

        // ==============================
        // LOKASI
        // ==============================

        TextView txtLokasi =
                new TextView(this);

        txtLokasi.setText(
                "📍 " + lokasi
        );

        txtLokasi.setTextSize(12);

        txtLokasi.setTextColor(
                0xFF64748B
        );

        // ==============================
        // GAJI
        // ==============================

        TextView txtGaji =
                new TextView(this);

        txtGaji.setText(
                gaji
        );

        txtGaji.setTextSize(13);

        txtGaji.setTextColor(
                0xFF1565C0
        );

        txtGaji.setTypeface(
                null,
                android.graphics.Typeface.BOLD
        );

        // ==============================
        // BUTTON
        // ==============================

        TextView btnDetail =
                new TextView(this);

        btnDetail.setText(
                "Lihat Detail"
        );

        btnDetail.setGravity(
                android.view.Gravity.CENTER
        );

        btnDetail.setTextColor(
                0xFFFFFFFF
        );

        btnDetail.setTextSize(13);

        btnDetail.setTypeface(
                null,
                android.graphics.Typeface.BOLD
        );

        btnDetail.setBackgroundResource(
                R.drawable.bg_button
        );

        LinearLayout.LayoutParams buttonParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        45
                );

        buttonParams.setMargins(
                0,
                15,
                0,
                0
        );

        btnDetail.setLayoutParams(
                buttonParams
        );

        // ==============================
        // TAMBAHKAN
        // ==============================

        card.addView(txtJudul);

        card.addView(txtPerusahaan);

        card.addView(txtLokasi);

        card.addView(txtGaji);

        card.addView(btnDetail);

        containerTersimpan.addView(card);

        // ==============================
        // DETAIL
        // ==============================

        btnDetail.setOnClickListener(v -> {

            bukaDetail(
                    judul,
                    perusahaan,
                    lokasi,
                    gaji,
                    lowonganId
            );

        });
    }

    private void bukaDetail(
            String judul,
            String perusahaan,
            String lokasi,
            String gaji,
            String lowonganId) {

        Intent intent =
                new Intent(
                        TersimpanActivity.this,
                        DetailLowonganActivity.class
                );

        intent.putExtra(
                "judul",
                judul
        );

        intent.putExtra(
                "perusahaan",
                perusahaan
        );

        intent.putExtra(
                "lokasi",
                lokasi
        );

        intent.putExtra(
                "tipe",
                "Full Time"
        );

        intent.putExtra(
                "gaji",
                gaji
        );

        intent.putExtra(
                "lowongan_id",
                lowonganId
        );

        intent.putExtra(
                "deskripsi",
                "Informasi lengkap mengenai posisi "
                        + judul
                        + " di "
                        + perusahaan
                        + "."
        );

        startActivity(intent);
    }
}