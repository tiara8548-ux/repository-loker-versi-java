package com.muti.lokerku_muti;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailLowonganActivity extends AppCompatActivity {

    private TextView txtJudul;
    private TextView txtPerusahaan;
    private TextView txtLokasi;
    private TextView txtDeskripsi;

    private Button btnLamar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_detail_lowongan);

        // =========================
        // HUBUNGKAN DENGAN XML
        // =========================

        txtJudul = findViewById(R.id.txtJudul);
        txtPerusahaan = findViewById(R.id.txtPerusahaan);
        txtLokasi = findViewById(R.id.txtLokasi);
        txtDeskripsi = findViewById(R.id.txtDeskripsi);

        btnLamar = findViewById(R.id.btnLamar);


        // =========================
        // AMBIL DATA DARI HOME
        // =========================

        String judul = getIntent().getStringExtra("judul");
        String perusahaan = getIntent().getStringExtra("perusahaan");
        String lokasi = getIntent().getStringExtra("lokasi");
        String deskripsi = getIntent().getStringExtra("deskripsi");

        String lowonganId = getIntent().getStringExtra("lowongan_id");


        // =========================
        // TAMPILKAN DATA
        // =========================

        if (judul != null) {
            txtJudul.setText(judul);
        }

        if (perusahaan != null) {
            txtPerusahaan.setText(perusahaan);
        }

        if (lokasi != null) {
            txtLokasi.setText(lokasi);
        }

        if (deskripsi != null) {
            txtDeskripsi.setText(deskripsi);
        }


        // =========================
        // CEK ID LOWONGAN
        // =========================

        if (lowonganId == null || lowonganId.isEmpty()) {

            lowonganId = "lowongan_" + judul;
        }


        // =========================
        // CEK STATUS LAMARAN
        // =========================

        SharedPreferences preferences =
                getSharedPreferences(
                        "data_lamaran",
                        MODE_PRIVATE
                );

        boolean sudahDilamar =
                preferences.getBoolean(
                        lowonganId,
                        false
                );


        if (sudahDilamar) {

            btnLamar.setText("SUDAH DILAMAR");

            btnLamar.setEnabled(false);

        } else {

            btnLamar.setText("LAMAR SEKARANG");

            btnLamar.setEnabled(true);
        }


        // =========================
        // TOMBOL LAMAR
        // =========================

        final String finalLowonganId = lowonganId;

        btnLamar.setOnClickListener(v -> {

            Intent intent = new Intent(
                    DetailLowonganActivity.this,
                    LamaranActivity.class
            );


            // Kirim data lowongan

            intent.putExtra(
                    "lowongan_id",
                    finalLowonganId
            );

            intent.putExtra(
                    "judul",
                    judul
            );

            intent.putExtra(
                    "perusahaan",
                    perusahaan
            );

            intent.putExtra(
                    "lokasi",
                    lokasi
            );

            intent.putExtra(
                    "deskripsi",
                    deskripsi
            );


            startActivity(intent);

        });
    }
}