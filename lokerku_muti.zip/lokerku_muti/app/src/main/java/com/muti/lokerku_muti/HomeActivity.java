package com.muti.lokerku_muti;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private LinearLayout btnIT;
    private LinearLayout btnDesign;
    private LinearLayout btnMarketing;
    private LinearLayout btnAdmin;

    private LinearLayout navHome;
    private LinearLayout navLowongan;
    private LinearLayout navTersimpan;
    private LinearLayout navProfil;

    private TextView btnBookmark1;
    private TextView btnBookmark2;
    private TextView btnBookmark3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home);

        // ==============================
        // KATEGORI
        // ==============================

        btnIT = findViewById(R.id.btnIT);
        btnDesign = findViewById(R.id.btnDesign);
        btnMarketing = findViewById(R.id.btnMarketing);
        btnAdmin = findViewById(R.id.btnAdmin);

        // ==============================
        // NAVIGASI
        // ==============================

        navHome = findViewById(R.id.navHome);
        navLowongan = findViewById(R.id.navLowongan);
        navTersimpan = findViewById(R.id.navTersimpan);
        navProfil = findViewById(R.id.navProfil);

        // ==============================
        // BOOKMARK
        // ==============================

        btnBookmark1 = findViewById(R.id.btnBookmark1);
        btnBookmark2 = findViewById(R.id.btnBookmark2);
        btnBookmark3 = findViewById(R.id.btnBookmark3);

        tampilkanStatusBookmark();

        // ==============================
        // BOOKMARK 1
        // ==============================

        btnBookmark1.setOnClickListener(v -> {

            ubahBookmark(
                    "LOKER001",
                    btnBookmark1
            );

        });

        // ==============================
        // BOOKMARK 2
        // ==============================

        btnBookmark2.setOnClickListener(v -> {

            ubahBookmark(
                    "LOKER002",
                    btnBookmark2
            );

        });

        // ==============================
        // BOOKMARK 3
        // ==============================

        btnBookmark3.setOnClickListener(v -> {

            ubahBookmark(
                    "LOKER003",
                    btnBookmark3
            );

        });

        // ==============================
        // DETAIL 1
        // ==============================

        TextView btnDetail1 =
                findViewById(R.id.btnDetail1);

        btnDetail1.setOnClickListener(v -> {

            bukaDetail(
                    "Android Developer",
                    "PT Teknologi Indonesia",
                    "Jakarta",
                    "Full Time",
                    "Rp 5 - 8 Juta / bulan",
                    "Bertanggung jawab mengembangkan aplikasi Android menggunakan Java, melakukan pengujian aplikasi, memperbaiki bug dan melakukan pemeliharaan aplikasi.",
                    "LOKER001"
            );

        });

        // ==============================
        // DETAIL 2
        // ==============================

        TextView btnDetail2 =
                findViewById(R.id.btnDetail2);

        btnDetail2.setOnClickListener(v -> {

            bukaDetail(
                    "UI/UX Designer",
                    "Creative Digital Studio",
                    "Bandung",
                    "Full Time",
                    "Rp 4 - 7 Juta / bulan",
                    "Membuat desain antarmuka aplikasi, wireframe, prototype dan meningkatkan pengalaman pengguna.",
                    "LOKER002"
            );

        });

        // ==============================
        // DETAIL 3
        // ==============================

        TextView btnDetail3 =
                findViewById(R.id.btnDetail3);

        btnDetail3.setOnClickListener(v -> {

            bukaDetail(
                    "Digital Marketing",
                    "PT Media Kreatif",
                    "Medan",
                    "Full Time",
                    "Rp 4 - 6 Juta / bulan",
                    "Membuat strategi pemasaran digital, mengelola media sosial dan menganalisis performa kampanye.",
                    "LOKER003"
            );

        });

        // ==============================
        // KATEGORI
        // ==============================

        btnIT.setOnClickListener(v ->
                bukaKategori("IT")
        );

        btnDesign.setOnClickListener(v ->
                bukaKategori("Design")
        );

        btnMarketing.setOnClickListener(v ->
                bukaKategori("Marketing")
        );

        btnAdmin.setOnClickListener(v ->
                bukaKategori("Admin")
        );

        // ==============================
        // NAV HOME
        // ==============================

        navHome.setOnClickListener(v -> {
            // Sudah di Home
        });

        // ==============================
        // NAV LOWONGAN
        // ==============================

        navLowongan.setOnClickListener(v -> {

            Intent intent = new Intent(
                    HomeActivity.this,
                    LowonganActivity.class
            );

            startActivity(intent);

        });

        // ==============================
        // NAV TERSIMPAN
        // ==============================

        navTersimpan.setOnClickListener(v -> {

            Intent intent = new Intent(
                    HomeActivity.this,
                    TersimpanActivity.class
            );

            startActivity(intent);

        });

        // ==============================
        // NAV PROFIL
        // ==============================

        navProfil.setOnClickListener(v -> {

            Intent intent = new Intent(
                    HomeActivity.this,
                    ProfileActivity.class
            );

            startActivity(intent);

        });

    }

    // ==================================================
    // BOOKMARK
    // ==================================================

    private void ubahBookmark(
            String lowonganId,
            TextView tombol) {

        SharedPreferences preferences =
                getSharedPreferences(
                        "bookmark_loker",
                        MODE_PRIVATE
                );

        boolean tersimpan =
                preferences.getBoolean(
                        lowonganId,
                        false
                );

        SharedPreferences.Editor editor =
                preferences.edit();

        if (tersimpan) {

            editor.putBoolean(
                    lowonganId,
                    false
            );

            tombol.setText("♡");

        } else {

            editor.putBoolean(
                    lowonganId,
                    true
            );

            tombol.setText("♥");

        }

        editor.apply();
    }

    // ==================================================
    // TAMPILKAN BOOKMARK
    // ==================================================

    private void tampilkanStatusBookmark() {

        SharedPreferences preferences =
                getSharedPreferences(
                        "bookmark_loker",
                        MODE_PRIVATE
                );

        if (preferences.getBoolean(
                "LOKER001",
                false
        )) {

            btnBookmark1.setText("♥");

        } else {

            btnBookmark1.setText("♡");

        }

        if (preferences.getBoolean(
                "LOKER002",
                false
        )) {

            btnBookmark2.setText("♥");

        } else {

            btnBookmark2.setText("♡");

        }

        if (preferences.getBoolean(
                "LOKER003",
                false
        )) {

            btnBookmark3.setText("♥");

        } else {

            btnBookmark3.setText("♡");

        }
    }

    // ==================================================
    // DETAIL
    // ==================================================

    private void bukaDetail(
            String judul,
            String perusahaan,
            String lokasi,
            String tipe,
            String gaji,
            String deskripsi,
            String lowonganId) {

        Intent intent = new Intent(
                HomeActivity.this,
                DetailLowonganActivity.class
        );

        intent.putExtra("judul", judul);
        intent.putExtra("perusahaan", perusahaan);
        intent.putExtra("lokasi", lokasi);
        intent.putExtra("tipe", tipe);
        intent.putExtra("gaji", gaji);
        intent.putExtra("deskripsi", deskripsi);
        intent.putExtra("lowongan_id", lowonganId);

        startActivity(intent);
    }

    // ==================================================
    // KATEGORI
    // ==================================================

    private void bukaKategori(String kategori) {

        Intent intent = new Intent(
                HomeActivity.this,
                KategoriActivity.class
        );

        intent.putExtra(
                "kategori",
                kategori
        );

        startActivity(intent);
    }

    // ==================================================
    // REFRESH
    // ==================================================

    @Override
    protected void onResume() {

        super.onResume();

        if (btnBookmark1 != null) {
            tampilkanStatusBookmark();
        }
    }
}