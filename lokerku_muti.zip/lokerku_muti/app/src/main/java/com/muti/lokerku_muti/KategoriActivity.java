package com.muti.lokerku_muti;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class KategoriActivity extends AppCompatActivity {

    // ==========================================
    // TEXTVIEW JUDUL KATEGORI
    // ==========================================

    private TextView txtJudulKategori;

    // ==========================================
    // LOWONGAN
    // ==========================================

    private TextView txtJudul1;
    private TextView txtPerusahaan1;
    private TextView txtLokasi1;
    private TextView txtGaji1;

    private TextView txtJudul2;
    private TextView txtPerusahaan2;
    private TextView txtLokasi2;
    private TextView txtGaji2;

    private TextView txtJudul3;
    private TextView txtPerusahaan3;
    private TextView txtLokasi3;
    private TextView txtGaji3;

    // ==========================================
    // BUTTON DETAIL
    // ==========================================

    private TextView btnDetail1;
    private TextView btnDetail2;
    private TextView btnDetail3;

    // ==========================================
    // BOOKMARK
    // ==========================================

    private TextView bookmark1;
    private TextView bookmark2;
    private TextView bookmark3;

    // ==========================================
    // KATEGORI
    // ==========================================

    private String kategori;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        // ==========================================
        // XML
        // ==========================================

        setContentView(R.layout.activity_kategori);

        // ==========================================
        // AMBIL KATEGORI DARI HOME
        // ==========================================

        kategori =
                getIntent().getStringExtra("kategori");

        // ==========================================
        // DEFAULT KATEGORI
        // ==========================================

        if (kategori == null || kategori.isEmpty()) {

            kategori = "IT";
        }

        // ==========================================
        // HUBUNGKAN XML
        // ==========================================

        txtJudulKategori =
                findViewById(R.id.txtJudulKategori);

        // ==========================================
        // LOWONGAN 1
        // ==========================================

        txtJudul1 =
                findViewById(R.id.txtJudul1);

        txtPerusahaan1 =
                findViewById(R.id.txtPerusahaan1);

        txtLokasi1 =
                findViewById(R.id.txtLokasi1);

        txtGaji1 =
                findViewById(R.id.txtGaji1);

        // ==========================================
        // LOWONGAN 2
        // ==========================================

        txtJudul2 =
                findViewById(R.id.txtJudul2);

        txtPerusahaan2 =
                findViewById(R.id.txtPerusahaan2);

        txtLokasi2 =
                findViewById(R.id.txtLokasi2);

        txtGaji2 =
                findViewById(R.id.txtGaji2);

        // ==========================================
        // LOWONGAN 3
        // ==========================================

        txtJudul3 =
                findViewById(R.id.txtJudul3);

        txtPerusahaan3 =
                findViewById(R.id.txtPerusahaan3);

        txtLokasi3 =
                findViewById(R.id.txtLokasi3);

        txtGaji3 =
                findViewById(R.id.txtGaji3);

        // ==========================================
        // BUTTON DETAIL
        // ==========================================

        btnDetail1 =
                findViewById(R.id.btnDetail1);

        btnDetail2 =
                findViewById(R.id.btnDetail2);

        btnDetail3 =
                findViewById(R.id.btnDetail3);

        // ==========================================
        // BOOKMARK
        // ==========================================

        bookmark1 =
                findViewById(R.id.bookmark1);

        bookmark2 =
                findViewById(R.id.bookmark2);

        bookmark3 =
                findViewById(R.id.bookmark3);

        // ==========================================
        // TOMBOL KEMBALI
        // ==========================================

        TextView btnBack =
                findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        // ==========================================
        // TAMPILKAN DATA KATEGORI
        // ==========================================

        tampilkanKategori();

        // ==========================================
        // TAMPILKAN STATUS BOOKMARK
        // ==========================================

        tampilkanStatusBookmark();

        // ==========================================
        // BOOKMARK 1
        // ==========================================

        bookmark1.setOnClickListener(v -> {

            ubahBookmark(
                    kategori + "_001",
                    bookmark1
            );

        });

        // ==========================================
        // BOOKMARK 2
        // ==========================================

        bookmark2.setOnClickListener(v -> {

            ubahBookmark(
                    kategori + "_002",
                    bookmark2
            );

        });

        // ==========================================
        // BOOKMARK 3
        // ==========================================

        bookmark3.setOnClickListener(v -> {

            ubahBookmark(
                    kategori + "_003",
                    bookmark3
            );

        });

        // ==========================================
        // DETAIL 1
        // ==========================================

        btnDetail1.setOnClickListener(v -> {

            bukaDetail(
                    txtJudul1.getText().toString(),
                    txtPerusahaan1.getText().toString(),
                    txtLokasi1.getText().toString(),
                    txtGaji1.getText().toString(),
                    getDeskripsi(
                            txtJudul1.getText().toString()
                    ),
                    kategori + "_001"
            );

        });

        // ==========================================
        // DETAIL 2
        // ==========================================

        btnDetail2.setOnClickListener(v -> {

            bukaDetail(
                    txtJudul2.getText().toString(),
                    txtPerusahaan2.getText().toString(),
                    txtLokasi2.getText().toString(),
                    txtGaji2.getText().toString(),
                    getDeskripsi(
                            txtJudul2.getText().toString()
                    ),
                    kategori + "_002"
            );

        });

        // ==========================================
        // DETAIL 3
        // ==========================================

        btnDetail3.setOnClickListener(v -> {

            bukaDetail(
                    txtJudul3.getText().toString(),
                    txtPerusahaan3.getText().toString(),
                    txtLokasi3.getText().toString(),
                    txtGaji3.getText().toString(),
                    getDeskripsi(
                            txtJudul3.getText().toString()
                    ),
                    kategori + "_003"
            );

        });
    }

    // =========================================================
    // TAMPILKAN KATEGORI
    // =========================================================

    private void tampilkanKategori() {

        // =====================================================
        // IT
        // =====================================================

        if (kategori.equalsIgnoreCase("IT")) {

            txtJudulKategori.setText(
                    "Lowongan IT"
            );

            // LOWONGAN 1

            txtJudul1.setText(
                    "Android Developer"
            );

            txtPerusahaan1.setText(
                    "PT Teknologi Indonesia"
            );

            txtLokasi1.setText(
                    "Jakarta"
            );

            txtGaji1.setText(
                    "Rp 5 - 8 Juta / bulan"
            );

            // LOWONGAN 2

            txtJudul2.setText(
                    "Web Developer"
            );

            txtPerusahaan2.setText(
                    "PT Digital Nusantara"
            );

            txtLokasi2.setText(
                    "Bandung"
            );

            txtGaji2.setText(
                    "Rp 5 - 9 Juta / bulan"
            );

            // LOWONGAN 3

            txtJudul3.setText(
                    "Backend Developer"
            );

            txtPerusahaan3.setText(
                    "Tech Solutions Indonesia"
            );

            txtLokasi3.setText(
                    "Surabaya"
            );

            txtGaji3.setText(
                    "Rp 6 - 10 Juta / bulan"
            );
        }

        // =====================================================
        // DESIGN
        // =====================================================

        else if (
                kategori.equalsIgnoreCase("Design")
                        ||
                        kategori.equalsIgnoreCase("Desain")
        ) {

            txtJudulKategori.setText(
                    "Lowongan Design"
            );

            // LOWONGAN 1

            txtJudul1.setText(
                    "UI/UX Designer"
            );

            txtPerusahaan1.setText(
                    "Creative Digital Studio"
            );

            txtLokasi1.setText(
                    "Bandung"
            );

            txtGaji1.setText(
                    "Rp 4 - 7 Juta / bulan"
            );

            // LOWONGAN 2

            txtJudul2.setText(
                    "Graphic Designer"
            );

            txtPerusahaan2.setText(
                    "Pixel Creative Agency"
            );

            txtLokasi2.setText(
                    "Jakarta"
            );

            txtGaji2.setText(
                    "Rp 4 - 6 Juta / bulan"
            );

            // LOWONGAN 3

            txtJudul3.setText(
                    "Illustrator"
            );

            txtPerusahaan3.setText(
                    "Visual Art Studio"
            );

            txtLokasi3.setText(
                    "Yogyakarta"
            );

            txtGaji3.setText(
                    "Rp 3 - 6 Juta / bulan"
            );
        }

        // =====================================================
        // MARKETING
        // =====================================================

        else if (
                kategori.equalsIgnoreCase("Marketing")
        ) {

            txtJudulKategori.setText(
                    "Lowongan Marketing"
            );

            // LOWONGAN 1

            txtJudul1.setText(
                    "Digital Marketing"
            );

            txtPerusahaan1.setText(
                    "PT Media Kreatif"
            );

            txtLokasi1.setText(
                    "Medan"
            );

            txtGaji1.setText(
                    "Rp 4 - 7 Juta / bulan"
            );

            // LOWONGAN 2

            txtJudul2.setText(
                    "Social Media Specialist"
            );

            txtPerusahaan2.setText(
                    "Social Media Indonesia"
            );

            txtLokasi2.setText(
                    "Jakarta"
            );

            txtGaji2.setText(
                    "Rp 4 - 6 Juta / bulan"
            );

            // LOWONGAN 3

            txtJudul3.setText(
                    "Content Creator"
            );

            txtPerusahaan3.setText(
                    "Creative Media Group"
            );

            txtLokasi3.setText(
                    "Bali"
            );

            txtGaji3.setText(
                    "Rp 3 - 6 Juta / bulan"
            );
        }

        // =====================================================
        // ADMIN
        // =====================================================

        else if (
                kategori.equalsIgnoreCase("Admin")
        ) {

            txtJudulKategori.setText(
                    "Lowongan Admin"
            );

            // LOWONGAN 1

            txtJudul1.setText(
                    "Admin Office"
            );

            txtPerusahaan1.setText(
                    "PT Maju Bersama"
            );

            txtLokasi1.setText(
                    "Jakarta"
            );

            txtGaji1.setText(
                    "Rp 3 - 5 Juta / bulan"
            );

            // LOWONGAN 2

            txtJudul2.setText(
                    "Staff Administrasi"
            );

            txtPerusahaan2.setText(
                    "PT Sukses Mandiri"
            );

            txtLokasi2.setText(
                    "Bekasi"
            );

            txtGaji2.setText(
                    "Rp 3 - 5 Juta / bulan"
            );

            // LOWONGAN 3

            txtJudul3.setText(
                    "Data Entry"
            );

            txtPerusahaan3.setText(
                    "Data Solutions"
            );

            txtLokasi3.setText(
                    "Tangerang"
            );

            txtGaji3.setText(
                    "Rp 3 - 5 Juta / bulan"
            );
        }

        // =====================================================
        // JIKA KATEGORI TIDAK DIKENAL
        // =====================================================

        else {

            txtJudulKategori.setText(
                    "Lowongan"
            );

            txtJudul1.setText(
                    "Belum ada lowongan"
            );

            txtPerusahaan1.setText(
                    "Data belum tersedia"
            );

            txtLokasi1.setText(
                    "-"
            );

            txtGaji1.setText(
                    "-"
            );

            txtJudul2.setText(
                    "-"
            );

            txtPerusahaan2.setText(
                    "-"
            );

            txtLokasi2.setText(
                    "-"
            );

            txtGaji2.setText(
                    "-"
            );

            txtJudul3.setText(
                    "-"
            );

            txtPerusahaan3.setText(
                    "-"
            );

            txtLokasi3.setText(
                    "-"
            );

            txtGaji3.setText(
                    "-"
            );
        }
    }

    // =========================================================
    // DESKRIPSI LOWONGAN
    // =========================================================

    private String getDeskripsi(
            String judul
    ) {

        // =====================================================
        // IT
        // =====================================================

        if (judul.equals("Android Developer")) {

            return "Bertanggung jawab mengembangkan aplikasi Android menggunakan Java, melakukan pengujian aplikasi, memperbaiki bug dan melakukan pemeliharaan aplikasi.";
        }

        if (judul.equals("Web Developer")) {

            return "Bertanggung jawab mengembangkan dan memelihara website perusahaan serta memastikan website dapat berjalan dengan baik di berbagai perangkat.";
        }

        if (judul.equals("Backend Developer")) {

            return "Bertanggung jawab mengembangkan sistem backend, API dan database untuk mendukung aplikasi perusahaan.";
        }

        // =====================================================
        // DESIGN
        // =====================================================

        if (judul.equals("UI/UX Designer")) {

            return "Membuat wireframe, prototype dan desain antarmuka aplikasi serta meningkatkan pengalaman pengguna.";
        }

        if (judul.equals("Graphic Designer")) {

            return "Membuat desain visual untuk kebutuhan promosi, media sosial dan branding perusahaan.";
        }

        if (judul.equals("Illustrator")) {

            return "Membuat ilustrasi digital untuk kebutuhan konten, promosi dan produk perusahaan.";
        }

        // =====================================================
        // MARKETING
        // =====================================================

        if (judul.equals("Digital Marketing")) {

            return "Menyusun strategi pemasaran digital, menjalankan kampanye online dan menganalisis hasil pemasaran perusahaan.";
        }

        if (judul.equals("Social Media Specialist")) {

            return "Mengelola media sosial perusahaan, membuat konten dan meningkatkan engagement dengan audiens.";
        }

        if (judul.equals("Content Creator")) {

            return "Membuat konten kreatif untuk media sosial, website dan kebutuhan promosi perusahaan.";
        }

        // =====================================================
        // ADMIN
        // =====================================================

        if (judul.equals("Admin Office")) {

            return "Mengelola dokumen, melakukan input data dan membantu kegiatan administrasi kantor.";
        }

        if (judul.equals("Staff Administrasi")) {

            return "Mengelola administrasi perusahaan, arsip dokumen dan membantu kebutuhan operasional kantor.";
        }

        if (judul.equals("Data Entry")) {

            return "Melakukan input dan pengolahan data perusahaan secara teliti dan terorganisir.";
        }

        return "Deskripsi pekerjaan belum tersedia.";
    }

    // =========================================================
    // BOOKMARK
    // =========================================================

    private void ubahBookmark(
            String id,
            TextView tombol
    ) {

        SharedPreferences preferences =
                getSharedPreferences(
                        "bookmark_loker",
                        MODE_PRIVATE
                );

        boolean sudahTersimpan =
                preferences.getBoolean(
                        id,
                        false
                );

        SharedPreferences.Editor editor =
                preferences.edit();

        if (sudahTersimpan) {

            // ==========================================
            // HAPUS DARI TERSIMPAN
            // ==========================================

            editor.putBoolean(
                    id,
                    false
            );

            tombol.setText("♡");

        } else {

            // ==========================================
            // SIMPAN
            // ==========================================

            editor.putBoolean(
                    id,
                    true
            );

            tombol.setText("♥");
        }

        editor.apply();
    }

    // =========================================================
    // CEK STATUS BOOKMARK
    // =========================================================

    private void tampilkanStatusBookmark() {

        SharedPreferences preferences =
                getSharedPreferences(
                        "bookmark_loker",
                        MODE_PRIVATE
                );

        // ==========================================
        // BOOKMARK 1
        // ==========================================

        boolean simpan1 =
                preferences.getBoolean(
                        kategori + "_001",
                        false
                );

        if (simpan1) {

            bookmark1.setText("♥");

        } else {

            bookmark1.setText("♡");
        }

        // ==========================================
        // BOOKMARK 2
        // ==========================================

        boolean simpan2 =
                preferences.getBoolean(
                        kategori + "_002",
                        false
                );

        if (simpan2) {

            bookmark2.setText("♥");

        } else {

            bookmark2.setText("♡");
        }

        // ==========================================
        // BOOKMARK 3
        // ==========================================

        boolean simpan3 =
                preferences.getBoolean(
                        kategori + "_003",
                        false
                );

        if (simpan3) {

            bookmark3.setText("♥");

        } else {

            bookmark3.setText("♡");
        }
    }

    // =========================================================
    // BUKA DETAIL LOWONGAN
    // =========================================================

    private void bukaDetail(
            String judul,
            String perusahaan,
            String lokasi,
            String gaji,
            String deskripsi,
            String lowonganId
    ) {

        Intent intent =
                new Intent(
                        KategoriActivity.this,
                        DetailLowonganActivity.class
                );

        // ==========================================
        // JUDUL
        // ==========================================

        intent.putExtra(
                "judul",
                judul
        );

        // ==========================================
        // PERUSAHAAN
        // ==========================================

        intent.putExtra(
                "perusahaan",
                perusahaan
        );

        // ==========================================
        // LOKASI
        // ==========================================

        intent.putExtra(
                "lokasi",
                lokasi
        );

        // ==========================================
        // TIPE PEKERJAAN
        // ==========================================

        intent.putExtra(
                "tipe",
                "Full Time"
        );

        // ==========================================
        // GAJI
        // ==========================================

        intent.putExtra(
                "gaji",
                gaji
        );

        // ==========================================
        // DESKRIPSI
        // ==========================================

        intent.putExtra(
                "deskripsi",
                deskripsi
        );

        // ==========================================
        // ID LOWONGAN
        // ==========================================

        intent.putExtra(
                "lowongan_id",
                lowonganId
        );

        // ==========================================
        // BUKA DETAIL
        // ==========================================

        startActivity(intent);
    }

    // =========================================================
    // REFRESH BOOKMARK SAAT KEMBALI KE HALAMAN
    // =========================================================

    @Override
    protected void onResume() {

        super.onResume();

        if (bookmark1 != null) {

            tampilkanStatusBookmark();
        }
    }
}